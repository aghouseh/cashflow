---
name: cashflow-handoff
description: >-
  Implement Cashflow design handoffs. Use whenever the user references a
  `design_handoff_cashflow_v*` bundle, a Cashflow mock/prototype, a cashflow
  design URL, or asks to build/recreate a Cashflow screen (Balance, Ledger,
  Entries, add/edit, mobile, auth/onboarding, or the locked/encrypted state).
  Carries the design tokens, conventions, and rules so no re-explaining is
  needed per revision.
---

# Cashflow design handoff

You are implementing screens from the **Cashflow** product into THIS repository.
The design source is a `design_handoff_cashflow_vN/` bundle whose **canonical
content is the `.jsx` and `.css` under `src/`**. Your job is to **recreate those
designs in this codebase's existing framework and patterns** — not to copy the
prototype code.

## Golden rules

1. **Read the `.jsx`/`.css` in `src/` — not the HTML.** Those components
   (React-via-Babel) are the ground truth for structure, styling, and behavior.
   Rebuild them in this repo's component library / state / routing / styling
   conventions. The `src/*.html` files are **load-order manifests + previews
   only** (plain `<script>` files sharing global scope via `window`) — open one
   to see how files compose or to preview in a browser, but don't parse HTML for
   layout. If you're handed a single inlined/bundled HTML instead of the source
   tree, treat it as a preview only and ask for the `src/` bundle.
2. **Read the bundle's `README.md` first.** It is the spec of record — layout
   intent, tokens, interactions, state shape, and out-of-scope notes. The
   newest `design_handoff_cashflow_vN` wins; check "What changed since…" at the
   top to see the delta.
3. **Match the visual system exactly.** Use the tokens below (they live in
   `src/midfi/styles.css` + `src/app/styles-app.css`). Mirror them into this
   repo's token layer (CSS vars / Tailwind theme / design tokens) rather than
   hardcoding hex inline.
4. **One scrub source of truth.** Everything time-related reads from a single
   integer `scrubOffsetDays` (0 = today). Drag, jump chips, date input, ledger
   scroll, and arrow-key stepping all just set that one value.
5. **Cadence math comes from the user's interval library at runtime** — do not
   hardcode the cadence options or reimplement week/bi-week/month-on-Nth logic.
   The `RECURRING` placeholder shape in the mock is throwaway. When the library
   can't express a cadence cleanly, surface it back to the user.
6. **When you hit anything marked out-of-scope** (error/loading states, banking
   integrations, scenarios, recovery flows, settings detail pages), pause and
   ask — those are deferred, not abandoned.

## Locked / encrypted state — extra care

The locked state (`src/app/locked.jsx`) is an **app-blocking** gate shown when
the device's local vault is encrypted-at-rest and currently sealed. Critical:

- It **wraps the live app** and renders it blurred + inert behind a frosted
  passphrase panel. Don't build a separate fake dashboard — blur the real one.
- **Enforce the block in route guards, not just visually.** No focus, no links,
  no nav reachable while locked (mobile gate covers the tab bar too).
- **The mock's plaintext `DEMO_PASS` compare is a stub.** In production NEVER
  store/compare the passphrase in plaintext. Derive a key (Argon2id / scrypt /
  PBKDF2 + per-device salt) and treat "unlock" as "decryption produced valid
  data." Keep key in memory only; clear on lock/timeout/background.
- "No recovery" is real for device-local encryption — honest copy + an explicit
  wipe-and-restore path, never a fake "reset."
- Decide the lock triggers (cold start, inactivity timeout, manual lock, OS
  background) and a wrong-attempt throttle/backoff policy.

## Design tokens (mirror these)

**Colour is owned by the `cashflow-design-system/` bundle** (`tokens.css` +
`tokens.json` + its README) — that is the source of truth. Mirror those
role-based `--cf-*` custom properties into this repo's token layer (CSS vars /
Tailwind theme / design tokens) rather than hardcoding hex. The system is three
families, each a **base · ink · soft** triad:

- **Neutral** (foundation): surfaces + a 4-step ink ramp + 2 hairlines, no
  saturation. Two temperatures — `warm` (default) and `cool`.
  - `bg #faf9f5` · `surface #ffffff` · `surface-2 #f4f3ee`
  - ink `#1a1a17` / `#56554e` / `#8d8b82` / `#c3c1b7`
  - lines `#eae8e1` (hairline) · `#d8d5cc` (control border)
- **Accent** (the one "live / now / focus" colour — **swappable**, default
  **indigo** `oklch(0.55 0.15 262)`): `--cf-accent` / `-ink` (text) / `-soft`
  (wash) / `-on` (text on the base fill). Set `data-accent="indigo|teal|violet|
  clay|bronze|slate"` at the root. **This replaces the legacy amber.**
- **Semantic** (fixed): **in/sage** `oklch(0.56 0.09 155)` and **out/terracotta**
  `oklch(0.57 0.13 27)`, each with `-ink` + `-soft`.

Colour rules (full list in the bundle README):
- **One accent, one job** — the accent is the ONLY "live/now/focus" colour
  (scrub marker, playhead, active row, primary button). Never decorative, never
  on income/expense.
- **`base` never floats on `soft`** — when an accent base mark sits on an accent
  soft fill (e.g. the ledger balance tooltip on the active row), break them with
  a surface-coloured halo ring + lift shadow (`--cf-ring-halo`,
  `--cf-shadow-lift`) so it reads as elevated.
- **Semantic = money only** — in/out appear on `↑`/`↓` glyphs and the number
  itself, never as filled bars, and never for UI state.
- All numerics use `tabular-nums` / `font-feature-settings: "tnum"`.

Type: **Geist** (UI) + **Geist Mono** (all numbers, dates, micro-labels).
- Hero display: Geist Mono 56px / -0.025em · display-sm 28px
- h1 18–22px / 500 · h2 14.5px / 500 · body 13.5px
- micro label: Geist Mono 10px / 500 / 0.09em / uppercase, ink-3

Radius: card/modal 14px · buttons & fields 8–10px · chips 999px.
Lines do the work — flat surfaces, `1px solid` hairlines, shadows only on
modal + the lock panel. Motion is quiet (120–150ms hover transitions; scrub is
instant; the lock reveal is the one expressive ~0.55s animation).

## Suggested workflow

1. Locate the newest `design_handoff_cashflow_vN/` and read `README.md` end to
   end. Treat `src/**/*.{jsx,css}` as the implementation reference; use the
   `src/*.html` files only to confirm load order / composition.
2. Map tokens → this repo's theme layer once, up front.
3. Build screen by screen, smallest reusable pieces first (TopBar, Hero,
   ChipRail, EntryRow, fields). Keep `scrubOffsetDays` central.
4. Wire cadence to the interval library; leave clear TODOs where product
   decisions are pending (out-of-scope list).
5. Diff your result against the mock screenshots/HTML for spacing + copy.
